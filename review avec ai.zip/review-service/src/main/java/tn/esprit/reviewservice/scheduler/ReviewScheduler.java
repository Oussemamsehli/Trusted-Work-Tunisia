package tn.esprit.reviewservice.scheduler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import tn.esprit.reviewservice.entity.GrowthProfile;
import tn.esprit.reviewservice.entity.Review;
import tn.esprit.reviewservice.entity.TrustScore;
import tn.esprit.reviewservice.repository.GrowthProfileRepository;
import tn.esprit.reviewservice.repository.ReviewRepository;
import tn.esprit.reviewservice.repository.TrustScoreRepository;
import tn.esprit.reviewservice.service.interfaces.IGeminiService;
import tn.esprit.reviewservice.service.interfaces.ITrustScoreService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ReviewScheduler {

    private final TrustScoreRepository trustScoreRepository;
    private final GrowthProfileRepository growthProfileRepository;
    private final ReviewRepository reviewRepository;
    private final ITrustScoreService trustScoreService;
    private final IGeminiService geminiService;

    /**
     * Scheduler 1 : Recalcul TrustScore + decay
     * Exécution : chaque jour à 3h du matin
     */
    @Scheduled(cron = "0 0 3 * * *")
    public void recalculateTrustScores() {
        log.info("=== SCHEDULER: Recalcul TrustScore lancé à {} ===", LocalDateTime.now());

        List<TrustScore> allScores = trustScoreRepository.findAll();
        int count = 0;

        for (TrustScore ts : allScores) {
            try {
                trustScoreService.recalculateTrustScore(ts.getUserId());
                count++;
            } catch (Exception e) {
                log.error("Erreur recalcul TrustScore userId={} : {}", ts.getUserId(), e.getMessage());
            }
        }

        log.info("=== SCHEDULER: {} TrustScores recalculés ===", count);
    }

    /**
     * Scheduler 2 : Vérification des streaks
     * Exécution : chaque jour à minuit
     */
    @Scheduled(cron = "0 0 0 * * *")
    public void verifyStreaks() {
        log.info("=== SCHEDULER: Vérification des streaks lancée à {} ===", LocalDateTime.now());

        LocalDate yesterday = LocalDate.now().minusDays(1);
        List<GrowthProfile> profiles = growthProfileRepository.findAll();
        int resetCount = 0;

        for (GrowthProfile gp : profiles) {
            if (gp.getStreakDays() != null
                    && gp.getStreakDays() > 0
                    && gp.getLastActivityDate() != null
                    && gp.getLastActivityDate().isBefore(yesterday)) {

                gp.setStreakDays(0);
                growthProfileRepository.save(gp);
                resetCount++;

                log.info("Streak reset: userId={} (lastActivityDate={})",
                        gp.getUserId(), gp.getLastActivityDate());
            }
        }

        log.info("=== SCHEDULER: {} streaks réinitialisés ===", resetCount);
    }

    /**
     * Scheduler 3 : Feature IA #4 — Détection d'anomalies de score
     * Exécution : chaque jour à 4h du matin (après le recalcul de 3h)
     *
     * Détecte :
     * - Chutes brutales (> 15 pts = SUSPICIOUS, > 25 = CRITICAL)
     * - Montées suspectes (> 20 pts = possible fake reviews)
     * - Avalanches d'avis (> 5 reviews en 24h)
     */
    @Scheduled(cron = "0 0 4 * * *")
    public void detectScoreAnomalies() {
        log.info("=== SCHEDULER: Détection d'anomalies IA lancée à {} ===", LocalDateTime.now());

        List<TrustScore> allScores = trustScoreRepository.findAll();
        int anomalyCount = 0;
        LocalDateTime last24h = LocalDateTime.now().minusHours(24);

        for (TrustScore ts : allScores) {
            try {
                Double currentScore = ts.getScore() != null ? ts.getScore() : 0.0;

                // Reviews reçues dans les dernières 24h
                List<Review> recentReviews = reviewRepository
                        .findByReviewedUserIdAndIsDeletedFalse(ts.getUserId())
                        .stream()
                        .filter(r -> r.getCreatedAt() != null && r.getCreatedAt().isAfter(last24h))
                        .toList();

                int recentCount = recentReviews.size();
                Double previousScore = estimatePreviousScore(ts, recentReviews);
                double variation = Math.abs(currentScore - previousScore);

                // Seuils
                boolean isAnomaly = variation > 15 || recentCount > 5;

                if (isAnomaly) {
                    anomalyCount++;
                    String anomalyType = variation > 25 ? "CRITICAL" : recentCount > 5 ? "REVIEW_AVALANCHE" : "SUSPICIOUS";

                    String aiAnalysis = geminiService.detectScoreAnomaly(
                            ts.getUserId(), previousScore, currentScore, recentCount
                    );

                    log.warn("=== ANOMALY [{}] === userId={}, score: {} → {} (variation={}), reviews24h={}",
                            anomalyType, ts.getUserId(),
                            String.format("%.2f", previousScore),
                            String.format("%.2f", currentScore),
                            String.format("%.2f", variation),
                            recentCount);
                    log.warn("AI Analysis userId={}: {}", ts.getUserId(), aiAnalysis);
                }

            } catch (Exception e) {
                log.error("Erreur détection anomalie userId={} : {}", ts.getUserId(), e.getMessage());
            }
        }

        log.info("=== SCHEDULER: Détection terminée — {} anomalies détectées ===", anomalyCount);
    }

    private Double estimatePreviousScore(TrustScore ts, List<Review> recentReviews) {
        if (recentReviews.isEmpty()) {
            return ts.getScore() != null ? ts.getScore() : 0.0;
        }

        double currentScore = ts.getScore() != null ? ts.getScore() : 0.0;
        double avgRecentRating = recentReviews.stream()
                .filter(r -> r.getNotePonderee() != null)
                .mapToDouble(Review::getNotePonderee)
                .average()
                .orElse(3.0);

        double impact = (avgRecentRating / 5.0) * 100.0;
        int totalReviews = ts.getTotalReviews() != null ? ts.getTotalReviews() : 1;

        double estimated = currentScore - ((impact - currentScore) * recentReviews.size() / Math.max(totalReviews, 1));
        return Math.max(0.0, Math.min(100.0, estimated));
    }
}
