package tn.esprit.reviewservice.service.interfaces;

import tn.esprit.reviewservice.dto.ai.AdminInsightDTO;
import tn.esprit.reviewservice.dto.ai.AiModerationResult;
import tn.esprit.reviewservice.dto.ai.ReviewSummaryDTO;

public interface IGeminiService {

    AiModerationResult analyzeReview(String comment, Double ratingAverage);

    ReviewSummaryDTO summarizeUserReviews(String reviewsText);

    AdminInsightDTO generateAdminInsight(String reviewComment, String reclamationReason);

    /**
     * Feature IA #4 — Détection d'anomalies de score
     */
    String detectScoreAnomaly(Long userId, Double oldScore, Double newScore, int recentReviewCount);

    /**
     * Feature IA #5 — Recommandation de badges
     */
    String recommendBadges(Long userId);
}