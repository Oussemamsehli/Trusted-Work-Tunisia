package tn.esprit.reviewservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.esprit.reviewservice.dto.ai.AdminInsightDTO;
import tn.esprit.reviewservice.dto.ai.ReviewSummaryDTO;
import tn.esprit.reviewservice.dto.request.ReviewRequest;
import tn.esprit.reviewservice.dto.response.ReviewResponse;
import tn.esprit.reviewservice.entity.Review;
import tn.esprit.reviewservice.repository.ReviewRepository;
import tn.esprit.reviewservice.service.interfaces.IGeminiService;
import tn.esprit.reviewservice.service.interfaces.IReviewService;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Tag(name = "Review", description = "Gestion des avis bidirectionnels (client ↔ freelancer)")
public class ReviewController {

    private final IReviewService reviewService;
    private final IGeminiService geminiService;
    private final ReviewRepository reviewRepository;

    // ==================== CRUD ====================

    @PostMapping
    @Operation(summary = "Soumettre un nouvel avis",
            description = "Crée un avis avec analyse IA (sentiment + riskScore). Auto-flagging si riskScore > 70.")
    public ResponseEntity<ReviewResponse> createReview(@RequestBody ReviewRequest request) {
        return ResponseEntity.ok(reviewService.createReview(request));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Modifier un avis",
            description = "Met à jour notes et commentaire, relance l'IA, recalcule TrustScore. Auto-flagging si suspect.")
    public ResponseEntity<ReviewResponse> updateReview(@PathVariable Long id,
                                                       @RequestBody ReviewRequest request) {
        return ResponseEntity.ok(reviewService.updateReview(id, request));
    }

    @GetMapping
    @Operation(summary = "Récupérer tous les avis", description = "Liste tous les avis non supprimés")
    public ResponseEntity<List<ReviewResponse>> getAllReviews() {
        return ResponseEntity.ok(reviewService.getAllReviews());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Récupérer un avis par ID")
    public ResponseEntity<ReviewResponse> getReview(@PathVariable Long id) {
        return ResponseEntity.ok(reviewService.getReviewById(id));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Avis reçus par un utilisateur")
    public ResponseEntity<List<ReviewResponse>> getReviewsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(reviewService.getReviewsByReviewedUser(userId));
    }

    @GetMapping("/contract/{contractId}")
    @Operation(summary = "Avis liés à un contrat")
    public ResponseEntity<List<ReviewResponse>> getReviewsByContract(@PathVariable Long contractId) {
        return ResponseEntity.ok(reviewService.getReviewsByContract(contractId));
    }

    @GetMapping("/visible")
    @Operation(summary = "Avis visibles uniquement", description = "Exclut les avis masqués par l'IA ou l'admin")
    public ResponseEntity<List<ReviewResponse>> getVisibleReviews() {
        return ResponseEntity.ok(reviewService.getVisibleReviews());
    }

    @GetMapping("/flagged")
    @Operation(summary = "Avis signalés", description = "Liste les avis flaggés par l'IA ou manuellement")
    public ResponseEntity<List<ReviewResponse>> getFlaggedReviews() {
        return ResponseEntity.ok(reviewService.getFlaggedReviews());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Supprimer un avis (soft delete)",
            description = "Marque l'avis comme supprimé, recalcule le TrustScore")
    public ResponseEntity<ReviewResponse> softDeleteReview(@PathVariable Long id) {
        return ResponseEntity.ok(reviewService.softDeleteReview(id));
    }

    // ==================== FEATURES IA ====================

    @GetMapping("/summary/{userId}")
    @Operation(summary = "Feature IA #3 — Résumé intelligent du profil",
            description = "Génère un résumé IA structuré basé sur les avis reçus")
    public ResponseEntity<ReviewSummaryDTO> getUserSummary(@PathVariable Long userId) {
        List<Review> reviews = reviewRepository.findByReviewedUserIdAndIsDeletedFalse(userId);

        if (reviews.isEmpty()) {
            ReviewSummaryDTO empty = new ReviewSummaryDTO();
            empty.setOverall("Aucune review disponible.");
            empty.setStrengths("N/A");
            empty.setWeaknesses("N/A");
            return ResponseEntity.ok(empty);
        }

        String allComments = reviews.stream()
                .map(Review::getComment)
                .filter(c -> c != null && !c.isBlank())
                .reduce("", (a, b) -> a + "\n" + b);

        return ResponseEntity.ok(geminiService.summarizeUserReviews(allComments));
    }

    @GetMapping("/admin-insight/{reviewId}")
    @Operation(summary = "Feature IA #3b — Insight admin",
            description = "Analyse de risque et recommandation admin pour un avis")
    public ResponseEntity<AdminInsightDTO> getAdminInsight(@PathVariable Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review introuvable avec id = " + reviewId));

        String reason = review.getIsFlagged() != null && review.getIsFlagged()
                ? "Flagged review — riskScore: " + review.getRiskScore()
                : "Manual admin review request";

        return ResponseEntity.ok(geminiService.generateAdminInsight(review.getComment(), reason));
    }

    @GetMapping("/ai/badge-recommendations/{userId}")
    @Operation(summary = "Feature IA #5 — Recommandation de badges",
            description = "L'IA suggère les prochains badges atteignables pour l'utilisateur")
    public ResponseEntity<String> getBadgeRecommendations(@PathVariable Long userId) {
        return ResponseEntity.ok(geminiService.recommendBadges(userId));
    }
}
