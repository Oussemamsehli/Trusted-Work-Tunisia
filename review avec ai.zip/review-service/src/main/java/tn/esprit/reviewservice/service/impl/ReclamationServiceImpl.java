package tn.esprit.reviewservice.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tn.esprit.reviewservice.dto.request.ReclamationRequest;
import tn.esprit.reviewservice.dto.response.ReclamationResponse;
import tn.esprit.reviewservice.entity.Reclamation;
import tn.esprit.reviewservice.entity.Review;
import tn.esprit.reviewservice.entity.enums.MotifReclamation;
import tn.esprit.reviewservice.entity.enums.StatusReclamation;
import tn.esprit.reviewservice.exception.ReclamationNotFoundException;
import tn.esprit.reviewservice.exception.ReviewNotFoundException;
import tn.esprit.reviewservice.mapper.ReviewMapper;
import tn.esprit.reviewservice.repository.ReclamationRepository;
import tn.esprit.reviewservice.repository.ReviewRepository;
import tn.esprit.reviewservice.service.interfaces.IReclamationService;
import tn.esprit.reviewservice.service.interfaces.ITrustScoreService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class ReclamationServiceImpl implements IReclamationService {

    private final ReclamationRepository reclamationRepository;
    private final ReviewRepository reviewRepository;
    private final ITrustScoreService trustScoreService;
    private final ReviewMapper mapper;

    // ===== Anti-spam : max 5 réclamations par jour par utilisateur =====
    private static final int MAX_RECLAMATIONS_PER_DAY = 5;

    @Override
    public ReclamationResponse createReclamation(ReclamationRequest request) {

        // --- Anti-spam : vérifier la limite journalière ---
        Long todayCount = reclamationRepository.countByUserAndToday(request.getReportedByUserId());
        if (todayCount != null && todayCount >= MAX_RECLAMATIONS_PER_DAY) {
            throw new RuntimeException(
                    "Limite de réclamations atteinte pour aujourd'hui ("
                            + MAX_RECLAMATIONS_PER_DAY + " max). Réessayez demain."
            );
        }

        Review review = reviewRepository.findById(request.getReviewId())
                .filter(r -> !Boolean.TRUE.equals(r.getIsDeleted()))
                .orElseThrow(() -> new ReviewNotFoundException(
                        "Review introuvable avec id = " + request.getReviewId()
                ));

        Reclamation reclamation = Reclamation.builder()
                .reportedByUserId(request.getReportedByUserId())
                .motif(request.getMotif())
                .description(request.getDescription())
                .status(StatusReclamation.PENDING)
                .review(review)
                .isAutoDetected(false)
                .build();

        Reclamation saved = reclamationRepository.save(reclamation);

        review.setIsFlagged(true);
        reviewRepository.save(review);

        return mapper.toReclamationResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public ReclamationResponse getById(Long id) {
        Reclamation reclamation = reclamationRepository.findById(id)
                .orElseThrow(() -> new ReclamationNotFoundException(
                        "Reclamation introuvable avec id = " + id
                ));

        return mapper.toReclamationResponse(reclamation);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReclamationResponse> getAllReclamations() {
        return reclamationRepository.findAllOrderByCreatedAtDesc()
                .stream()
                .map(mapper::toReclamationResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReclamationResponse> getByStatus(StatusReclamation status) {
        return reclamationRepository.findByStatusOrdered(status)
                .stream()
                .map(mapper::toReclamationResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReclamationResponse> getPendingReclamations() {
        return reclamationRepository.findPendingReclamations()
                .stream()
                .map(mapper::toReclamationResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReclamationResponse> getByReviewId(Long reviewId) {
        return reclamationRepository.findByReviewId(reviewId)
                .stream()
                .map(mapper::toReclamationResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReclamationResponse> getByReportedByUserId(Long reportedByUserId) {
        return reclamationRepository.findUserReclamations(reportedByUserId)
                .stream()
                .map(mapper::toReclamationResponse)
                .collect(Collectors.toList());
    }

    /**
     * Confirmer une réclamation :
     * - La review est masquée (isVisible = false)
     * - Le TrustScore du freelancer est recalculé (impact direct)
     * - Pénalité selon le motif de la réclamation
     */
    @Override
    public ReclamationResponse confirmReclamation(Long id) {
        Reclamation reclamation = reclamationRepository.findById(id)
                .orElseThrow(() -> new ReclamationNotFoundException(
                        "Reclamation introuvable avec id = " + id
                ));

        reclamation.setStatus(StatusReclamation.CONFIRMED);
        reclamation.setResolvedAt(LocalDateTime.now());

        // Masquer la review
        Review review = reclamation.getReview();
        review.setIsFlagged(true);
        review.setIsVisible(false);
        reviewRepository.save(review);

        Reclamation saved = reclamationRepository.save(reclamation);

        // --- IMPACT TRUSTSCORE : recalculer après masquage de la review ---
        // La review masquée (isVisible=false) est exclue du calcul,
        // donc le TrustScore du reviewedUser sera naturellement pénalisé
        try {
            trustScoreService.recalculateTrustScore(review.getReviewedUserId());
            log.info("TrustScore recalculé après confirmation réclamation id={}, reviewedUserId={}",
                    id, review.getReviewedUserId());
        } catch (Exception e) {
            log.error("Erreur recalcul TrustScore après confirmation réclamation: {}", e.getMessage());
        }

        return mapper.toReclamationResponse(saved);
    }

    /**
     * Rejeter une réclamation :
     * - La review redevient visible
     * - Le TrustScore est recalculé (la review compte à nouveau)
     */
    @Override
    public ReclamationResponse dismissReclamation(Long id) {
        Reclamation reclamation = reclamationRepository.findById(id)
                .orElseThrow(() -> new ReclamationNotFoundException(
                        "Reclamation introuvable avec id = " + id
                ));

        reclamation.setStatus(StatusReclamation.DISMISSED);
        reclamation.setResolvedAt(LocalDateTime.now());

        // Réhabiliter la review
        Review review = reclamation.getReview();
        review.setIsVisible(true);
        review.setIsFlagged(false);
        reviewRepository.save(review);

        Reclamation saved = reclamationRepository.save(reclamation);

        // Recalculer le TrustScore (review réintégrée)
        try {
            trustScoreService.recalculateTrustScore(review.getReviewedUserId());
            log.info("TrustScore recalculé après rejet réclamation id={}, reviewedUserId={}",
                    id, review.getReviewedUserId());
        } catch (Exception e) {
            log.error("Erreur recalcul TrustScore après rejet réclamation: {}", e.getMessage());
        }

        return mapper.toReclamationResponse(saved);
    }
}
