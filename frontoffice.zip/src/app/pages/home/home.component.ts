import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  constructor(private auth: AuthService) {}

  isLoggedIn(): boolean {
    return !!this.auth.getEmail();
  }

  getEmail(): string {
    return this.auth.getEmail();
  }
}